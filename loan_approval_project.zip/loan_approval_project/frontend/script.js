let currentUser = null;
let userAnalytics = null;
const API_URL = 'http://127.0.0.1:8000';

function toggleForms(e) {
    e.preventDefault();
    document.getElementById('login-form').classList.toggle('active');
    document.getElementById('signup-form').classList.toggle('active');
}

async function handleSignup() {
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const confirm = document.getElementById('signup-confirm').value;

    if (!name || !email || !password || !confirm) {
        alert('Please fill all fields');
        return;
    }

    if (password !== confirm) {
        alert('Passwords do not match');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/signup?email=${email}&password=${password}&name=${name}`, {
            method: 'POST'
        });
        const data = await response.json();
        
        if (response.ok) {
            alert('Account created! You can now login.');
            toggleForms({ preventDefault: () => {} });
            document.getElementById('signup-form').classList.remove('active');
            document.getElementById('login-form').classList.add('active');
        } else {
            alert('Error: ' + data.detail);
        }
    } catch (e) {
        alert('Connection error: ' + e.message);
    }
}

async function handleLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    if (!email || !password) {
        alert('Please enter email and password');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/login?email=${email}&password=${password}`, {
            method: 'POST'
        });
        const data = await response.json();

        if (response.ok) {
            currentUser = { email, name: data.name, token: data.token };
            document.getElementById('auth-container').style.display = 'none';
            document.getElementById('dashboard-container').style.display = 'flex';
            document.getElementById('user-name').textContent = data.name;
            document.getElementById('welcome-name').textContent = data.name;
            loadAnalytics();
        } else {
            alert('Invalid credentials');
        }
    } catch (e) {
        alert('Connection error: ' + e.message);
    }
}

function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        currentUser = null;
        document.getElementById('auth-container').style.display = 'flex';
        document.getElementById('dashboard-container').style.display = 'none';
        document.getElementById('login-email').value = '';
        document.getElementById('login-password').value = '';
    }
}

function navigatePage(e, page) {
    if (e) e.preventDefault();
    
    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${page}"]`).classList.add('active');

    // Update active page
    document.querySelectorAll('.page').forEach(p => {
        p.classList.remove('active');
    });
    document.getElementById(`${page}-page`).classList.add('active');

    // Update title
    const titles = {
        dashboard: 'Dashboard',
        predict: 'Get Prediction',
        analytics: 'Analytics',
        historical: 'Historical Data',
        profile: 'Profile'
    };
    document.getElementById('page-title').textContent = titles[page];

    // Load page content
    if (page === 'analytics') {
        setTimeout(() => renderCharts(), 100);
    } else if (page === 'historical') {
        loadHistoricalData();
    } else if (page === 'profile') {
        updateProfilePage();
    }
}

async function loadAnalytics() {
    try {
        const response = await fetch(`${API_URL}/analytics/${currentUser.email}`);
        userAnalytics = await response.json();
        updateDashboard();
    } catch (e) {
        console.error('Error loading analytics:', e);
    }
}

function updateDashboard() {
    if (!userAnalytics) return;

    // Update stat cards
    document.getElementById('total-predictions').textContent = userAnalytics.total_predictions;
    document.getElementById('approved-count').textContent = userAnalytics.approved_count;
    document.getElementById('rejected-count').textContent = userAnalytics.rejected_count;
    document.getElementById('approval-rate').textContent = userAnalytics.approval_rate + '%';

    // Update recent predictions
    const recentList = document.getElementById('recent-list');
    recentList.innerHTML = '';

    if (!userAnalytics.predictions || userAnalytics.predictions.length === 0) {
        recentList.innerHTML = '<p style="color: #6b7280; text-align: center; padding: 20px;">No predictions yet</p>';
    } else {
        userAnalytics.predictions.slice(0, 5).forEach(pred => {
            const item = document.createElement('div');
            item.className = 'prediction-item';
            const statusClass = pred.status === 'Approved' ? 'approved' : 'rejected';
            const statusIcon = pred.status === 'Approved' ? '✓' : '✗';
            const timestamp = new Date(pred.timestamp).toLocaleDateString();
            
            item.innerHTML = `
                <div>
                    <strong>${pred.status}</strong>
                    <small style="color: #6b7280; display: block;">${timestamp}</small>
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <span class="status-badge ${statusClass}">${statusIcon} ${pred.probability}%</span>
                </div>
            `;
            recentList.appendChild(item);
        });
    }

    // Update insights
    const insightsBox = document.getElementById('insights-box');
    insightsBox.innerHTML = '';
    
    const insights = [];
    if (userAnalytics.total_predictions > 0) {
        insights.push(`<div class="insight-item"><strong>📊 Total Predictions:</strong> ${userAnalytics.total_predictions}</div>`);
        insights.push(`<div class="insight-item"><strong>✅ Success Rate:</strong> ${userAnalytics.approval_rate}%</div>`);
        insights.push(`<div class="insight-item"><strong>💰 Average Loan:</strong> ₹${userAnalytics.avg_loan_amount.toLocaleString()}</div>`);
        if (userAnalytics.avg_probability) {
            insights.push(`<div class="insight-item"><strong>📈 Avg Approval Probability:</strong> ${userAnalytics.avg_probability}%</div>`);
        }
    } else {
        insights.push('<div class="insight-item">👉 Make your first prediction to see insights!</div>');
    }
    insightsBox.innerHTML = insights.join('');
}

async function handlePrediction(e) {
    e.preventDefault();

    const gender = document.getElementById('gender').value;
    const married = document.getElementById('married').value;
    const education = document.getElementById('education').value;
    const selfEmployed = document.getElementById('self-employed').value;
    const income = parseFloat(document.getElementById('income').value);
    const coincome = parseFloat(document.getElementById('coincome').value);
    const loan = parseFloat(document.getElementById('loan').value);
    const loanTerm = parseInt(document.getElementById('loan-term').value);
    const credit = parseInt(document.getElementById('credit').value);
    const propertyArea = document.getElementById('property-area').value;

    // More precise validation - check for actual NaN instead of falsy values
    if (!gender || !married || !education || !selfEmployed || isNaN(income) || isNaN(coincome) || isNaN(loan) || isNaN(loanTerm) || !propertyArea) {
        alert('Please fill all fields');
        return;
    }
    
    // Additional check for required positive values
    if (income <= 0 || loan <= 0 || loanTerm <= 0) {
        alert('Please enter valid positive numbers for Income, Loan Amount, and Loan Term');
        return;
    }

    try {
        const data = {
            Gender: gender,
            Married: married,
            Dependents: 0,
            Education: education,
            Self_Employed: selfEmployed,
            ApplicantIncome: income,
            CoapplicantIncome: coincome,
            LoanAmount: loan,
            Loan_Amount_Term: loanTerm,
            Credit_History: credit,
            Property_Area: propertyArea
        };

        const response = await fetch(`${API_URL}/predict?email=${currentUser.email}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            const resultDiv = document.getElementById('prediction-result');
            const statusClass = result.Loan_Status === 'Approved' ? 'result-approved' : 'result-rejected';
            const statusEmoji = result.Loan_Status === 'Approved' ? '✅' : '❌';

            document.getElementById('result-status').innerHTML = `<div class="result-box ${statusClass}">${statusEmoji} ${result.Loan_Status}</div>`;
            
            // Show detailed probability and explanation
            let detailsHTML = `
                <div class="probability-box">
                    <strong>Approval Probability: ${result.Probability}%</strong>
                    <br><small style="color: #6b7280;">Rejection Probability: ${result.Rejection_Probability}%</small>
                </div>
            `;
            
            if (result.Explanation) {
                detailsHTML += `
                    <div style="background: #f3f4f6; padding: 12px; border-radius: 8px; margin-top: 10px; font-size: 14px; line-height: 1.5;">
                        <strong>Explanation:</strong> ${result.Explanation}
                    </div>
                `;
            }
            
            if (result.Basis) {
                detailsHTML += `
                    <div style="background: #f9fafb; padding: 12px; border-radius: 8px; margin-top: 10px; font-size: 13px;">
                        <strong>Decision Basis:</strong>
                        <ul style="margin: 8px 0; padding-left: 20px;">
                            <li>Credit History: ${result.Basis.credit_history === 1 ? 'Good' : 'Poor'}</li>
                            <li>Income-to-Loan Ratio: ${result.Basis.income_loan_ratio}</li>
                            <li>Requested Loan: Rs ${result.Basis.loan_amount.toLocaleString()}</li>
                            <li>Education: ${result.Basis.education}</li>
                        </ul>
                    </div>
                `;
            }
            
            document.getElementById('result-probability').innerHTML = detailsHTML;
            resultDiv.style.display = 'block';

            // Reload analytics
            await loadAnalytics();
        } else {
            alert('Error: ' + result.detail);
        }
    } catch (e) {
        alert('Error: ' + e.message);
    }
}

function renderCharts() {
    if (!userAnalytics) return;

    const ctx = document.getElementById('statusChart');
    if (!ctx) return;

    // Destroy existing chart if it exists
    if (window.statusChartInstance) {
        window.statusChartInstance.destroy();
    }

    // Create new chart
    window.statusChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Approved', 'Rejected'],
            datasets: [{
                data: [userAnalytics.approved_count, userAnalytics.rejected_count],
                backgroundColor: ['#10b981', '#ef4444'],
                borderColor: ['#059669', '#dc2626'],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Update stats
    const statsDiv = document.getElementById('loan-stats');
    statsDiv.innerHTML = `
        <div class="loan-stat">
            <strong>Total Predictions:</strong>
            <span>${userAnalytics.total_predictions}</span>
        </div>
        <div class="loan-stat">
            <strong>Approved:</strong>
            <span>${userAnalytics.approved_count}</span>
        </div>
        <div class="loan-stat">
            <strong>Rejected:</strong>
            <span>${userAnalytics.rejected_count}</span>
        </div>
        <div class="loan-stat">
            <strong>Approval Rate:</strong>
            <span>${userAnalytics.approval_rate}%</span>
        </div>
        <div class="loan-stat">
            <strong>Avg Loan Amount:</strong>
            <span>₹${userAnalytics.avg_loan_amount.toLocaleString()}</span>
        </div>
    `;

    // Update predictions table
    const tableBody = document.getElementById('table-body');
    tableBody.innerHTML = '';
    
    if (userAnalytics.predictions && userAnalytics.predictions.length > 0) {
        userAnalytics.predictions.forEach(pred => {
            const row = tableBody.insertRow();
            const date = new Date(pred.timestamp).toLocaleDateString();
            row.innerHTML = `
                <td>${date}</td>
                <td><span class="status-badge ${pred.status === 'Approved' ? 'approved' : 'rejected'}">${pred.status}</span></td>
                <td>${pred.probability}%</td>
                <td>₹${pred.loan_amount.toLocaleString()}</td>
            `;
        });
    } else {
        const row = tableBody.insertRow();
        row.innerHTML = '<td colspan="4" style="text-align: center; color: #6b7280;">No predictions yet</td>';
    }
}

async function loadHistoricalData() {
    try {
        const response = await fetch(`${API_URL}/historical-data/${currentUser.email}`);
        const data = await response.json();

        const content = document.getElementById('historical-content');
        content.innerHTML = '';

        if (!data.data || data.data.length === 0) {
            content.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 40px;">No historical data available. Make predictions to build history.</p>';
            return;
        }

        // Display insights
        if (data.insights) {
            const insightsDiv = document.createElement('div');
            insightsDiv.className = 'card';
            insightsDiv.innerHTML = `
                <h3><i class="fas fa-lightbulb"></i> AI Recommendations</h3>
                <div class="insight-item">
                    <strong>✓ Approved Avg Probability:</strong> ${data.insights.avg_approved_probability}%
                </div>
                <div class="insight-item">
                    <strong>✗ Rejected Avg Probability:</strong> ${data.insights.avg_rejected_probability}%
                </div>
                <div class="insight-item">
                    <strong>→ Recommendation:</strong> ${data.insights.recommendation}
                </div>
            `;
            content.appendChild(insightsDiv);
        }

        // Display historical data
        const historyDiv = document.createElement('div');
        historyDiv.className = 'card';
        historyDiv.innerHTML = '<h3><i class="fas fa-history"></i> Prediction History</h3>';
        
        const historyList = document.createElement('div');
        historyList.className = 'historical-content';
        
        data.data.forEach(item => {
            const histItem = document.createElement('div');
            histItem.className = 'historical-item';
            histItem.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong>Loan: ₹${item.loan.toLocaleString()}</strong>
                        <br>
                        <small style="color: #6b7280;">Credit History: ${item.credit}</small>
                    </div>
                    <div style="text-align: right;">
                        <div class="status-badge ${item.status === 'Approved' ? 'approved' : 'rejected'}">${item.status}</div>
                        <small style="color: #6b7280; display: block; margin-top: 4px;">${item.prob}%</small>
                    </div>
                </div>
            `;
            historyList.appendChild(histItem);
        });
        
        historyDiv.appendChild(historyList);
        content.appendChild(historyDiv);
    } catch (e) {
        console.error('Error loading historical data:', e);
    }
}

function updateProfilePage() {
    if (!userAnalytics) return;

    document.getElementById('profile-name').textContent = currentUser.name;
    document.getElementById('profile-email').textContent = currentUser.email;
    document.getElementById('member-since').textContent = userAnalytics.member_since || '2024-01-01';
    document.getElementById('profile-total').textContent = userAnalytics.total_predictions;
    document.getElementById('profile-success').textContent = userAnalytics.approval_rate + '%';
    document.getElementById('profile-avg-loan').textContent = '₹' + userAnalytics.avg_loan_amount.toLocaleString();
}

// Load demo credentials on page load
window.addEventListener('load', () => {
    document.getElementById('login-email').value = 'demo@example.com';
    document.getElementById('login-password').value = 'demo123';
}); 