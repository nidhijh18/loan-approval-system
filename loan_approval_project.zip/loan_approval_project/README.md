# 🏦 LoanEase - AI-Powered Loan Approval System

A modern full-stack web application that uses machine learning to predict loan approval status with an intuitive dashboard for tracking predictions and analytics.

---

## 🎯 Features

### 🔐 Authentication
- **User Signup**: Create new accounts with email and password
- **User Login**: Secure authentication with session tokens
- **Demo Account**: Pre-configured demo credentials for testing

### 🎲 Loan Predictions
- **AI-Powered Predictions**: XGBoost ML model for accurate loan approval predictions
- **Feature Engineering**: Automatic calculation of derived features (income ratios, loan-to-income, etc.)
- **Probability Scores**: Get approval probability percentages (0-100%)

### 📊 Analytics Dashboard
- **Real-time Statistics**: Total predictions, approval rates, rejection counts
- **Visual Charts**: Interactive doughnut charts showing approval vs rejection distribution
- **Historical Data**: Complete prediction history with dates and details
- **Performance Insights**: Average loan amounts, success rates, and personalized recommendations

### 💾 Data Persistence
- **SQLite Database**: All user data and predictions are permanently stored
- **Historical Tracking**: Build prediction history for future analysis
- **Data Recovery**: Access past predictions anytime

### 🎨 Modern UI
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Professional Styling**: Modern gradient backgrounds, smooth animations
- **Intuitive Navigation**: 5-page dashboard with easy navigation
- **Real-time Updates**: Instant feedback on predictions and analytics

---

## 🛠️ Tech Stack

### Backend
- **Framework**: FastAPI (Python)
- **Server**: Uvicorn
- **Database**: SQLite3
- **ML Model**: XGBoost
- **Data Processing**: Pandas, NumPy

### Frontend
- **HTML5**: Semantic markup
- **CSS3**: Modern styling with animations and gradients
- **JavaScript**: Vanilla JS (no frameworks required)
- **Charts**: Chart.js for data visualization
- **Icons**: Font Awesome

### Dependencies
All dependencies are listed in `requirements.txt`

---

## 📋 Project Structure

```
loan_approval_project/
├── backend/
│   ├── main.py                 # FastAPI application (6 endpoints)
│   └── __pycache__/           # Python cache (auto-generated)
├── frontend/
│   ├── index.html             # Main HTML page
│   ├── style.css              # Modern CSS styling (1000+ lines)
│   └── script.js              # Application logic
├── model/
│   ├── model.pkl              # XGBoost trained model
│   └── features.pkl           # Feature list for predictions
├── loan_data.db               # SQLite database (auto-created)
├── requirements.txt           # Python dependencies
└── README.md                  # This file
```

---

## 🚀 Getting Started

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- macOS, Linux, or Windows

### Installation

1. **Clone or download the project**
   ```bash
   cd loan_approval_project
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the backend server**
   ```bash
   cd backend
   python -m uvicorn main:app --host 127.0.0.1 --port 8000
   ```
   The server will start at `http://127.0.0.1:8000`

4. **Open the frontend**
   - Open `frontend/index.html` in your web browser
   - Or use a simple HTTP server: `python -m http.server 8080` in the frontend folder

### Demo Account
- **Email**: demo@example.com
- **Password**: demo123

---

## 📚 API Endpoints

### Authentication
- `POST /signup` - Register new user
  - Parameters: `email`, `password`, `name`
  - Response: User created confirmation

- `POST /login` - Login user
  - Parameters: `email`, `password`
  - Response: User data and token

### Predictions
- `POST /predict` - Get loan prediction
  - Parameters: `email`, loan data (JSON body)
  - Response: Loan status and probability

### Analytics
- `GET /analytics/{email}` - Get user statistics
  - Response: Total predictions, approval rate, prediction history

- `GET /profile/{email}` - Get user profile
  - Response: User info and membership details

- `GET /historical-data/{email}` - Get historical insights
  - Response: Past predictions and recommendations

---

## 💡 How It Works

### Prediction Process
1. User enters loan details (income, education, credit history, etc.)
2. System applies feature engineering (calculates ratios, log values)
3. XGBoost model makes prediction
4. Result (Approved/Rejected) and probability stored in database
5. Dashboard updates with new prediction data

### Feature Engineering
The system automatically calculates:
- **Total Income**: Applicant + Co-applicant Income
- **Log Income**: Log transformation of total income
- **Log Loan Amount**: Log transformation of loan amount
- **Income-to-Loan Ratio**: Income / Loan Amount ratio
- **Loan Per Term**: Loan / Term ratio
- **Credit-Income Factor**: Credit history × Total income

---

## 🗄️ Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

### Predictions Table
```sql
CREATE TABLE predictions (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    education TEXT,
    applicant_income REAL,
    coapplicant_income REAL,
    loan_amount REAL,
    loan_term INTEGER,
    credit_history INTEGER,
    property_area TEXT,
    predicted_status TEXT,
    probability REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)
```

---

## 🎨 Dashboard Pages

1. **Dashboard** - Overview with key statistics and recent predictions
2. **Get Prediction** - Form to input loan details and get predictions
3. **Analytics** - Charts and tables showing historical data
4. **History** - Detailed historical data with insights and recommendations
5. **Profile** - User profile and account information

---

## 🔒 Security Notes

- Passwords are stored as plain text (for demo purposes only)
- In production, use bcrypt or argon2 for password hashing
- Consider adding JWT tokens for API security
- Add HTTPS for production deployment

---

## 🚢 Deployment

### Production Checklist
- [ ] Hash passwords with bcrypt
- [ ] Use environment variables for sensitive data
- [ ] Add HTTPS/SSL certificate
- [ ] Set up proper CORS for frontend domain
- [ ] Add rate limiting
- [ ] Implement proper error handling
- [ ] Add logging and monitoring
- [ ] Use production ASGI server (gunicorn + uvicorn)

---

## 📝 Known Limitations

- Passwords stored as plain text (demo only)
- No email verification
- No password reset functionality
- Single-page dashboard (no mobile app)
- ML model is pre-trained (no training interface)

---

## 🐛 Troubleshooting

### Backend won't start
```bash
# Kill any existing uvicorn process
pkill -f uvicorn

# Try again
cd backend && python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

### Database errors
```bash
# Delete database to reset (WARNING: Clears all data)
rm loan_data.db

# Restart backend - database will be recreated
```

### Port 8000 already in use
```bash
# Use different port
python -m uvicorn main:app --host 127.0.0.1 --port 8001
```

---

## 📄 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| fastapi | 0.135.0 | Web framework |
| uvicorn | 0.41.0 | ASGI server |
| pandas | 2.3.3 | Data processing |
| numpy | 2.4.2 | Numerical computing |
| xgboost | 2.1.3 | ML model |
| scikit-learn | 1.5.1 | ML utilities |
| python-multipart | 0.0.6 | Form parsing |

---

## 📞 Support

For issues or questions:
1. Check the README
2. Review backend logs for error messages
3. Check browser console for frontend errors
4. Verify database file exists (`loan_data.db`)

---

## 📜 License

This project is provided as-is for educational and demonstration purposes.

---

## 🎓 Learning Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [XGBoost Guide](https://xgboost.readthedocs.io/)
- [SQLite Tutorial](https://www.sqlite.org/lang.html)
- [Chart.js Docs](https://www.chartjs.org/docs/latest/)

---

**LoanEase** - Making loan predictions smarter, faster, and more transparent ✨
