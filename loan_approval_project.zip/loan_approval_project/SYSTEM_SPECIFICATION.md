# LoanEase - Complete System Specification & Verification

## Input Specifications

### Income Parameters
- **Applicant Income**: ANNUAL income in Indian Rupees (Rs)
- **Co-applicant Income**: ANNUAL income in Indian Rupees (Rs) - can be 0 if no co-applicant
- **Range**: 50,000 - 500,000 Rs per year
- **Example**: Annual salary of Rs 200,000

### Loan Parameters
- **Loan Amount**: Principal amount requested in Indian Rupees (Rs)
- **Range**: 10,000 - 500,000 Rs
- **Loan Term**: Duration in MONTHS (not years)
- **Typical values**: 36 (3 years), 60 (5 years), 84 (7 years), 120 (10 years), 180 (15 years), 240 (20 years), 360 (30 years)

### Personal Information
- **Gender**: Male / Female
- **Marital Status**: Married / Single
- **Education**: Graduate / Not Graduate
- **Self Employed**: Yes / No
- **Property Area**: Urban / Semiurban / Rural
- **Dependents**: Fixed at 0 (not in form)

### Credit History
- **0**: Bad/No Credit History
- **1**: Good Credit History

---

## Model Logic & Approval Criteria

### Key Factors (in order of importance)
1. **Credit History** (30% weight)
   - Good credit (1): Strong positive signal
   - Bad credit (0): Major negative signal

2. **Income-to-Loan Ratio** (40% weight)
   - Ratio > 5.0: Excellent (+40% approval)
   - Ratio > 2.5: Good (+25% approval)
   - Ratio < 1.5: Poor (negative impact)
   - Ratio < 0.5: Critical (high rejection)

3. **Education & Employment** (15% weight)
   - Graduate: +10% approval
   - Not self-employed: +5% approval (lower risk)

4. **Property Area** (10% weight)
   - Urban: +5% approval (better market)
   - Semiurban/Rural: Neutral

5. **Income Stability** (5% weight)
   - Primary income > Co-applicant: +10%

---

## Calculated Features

The model calculates:
- **TotalIncome** = ApplicantIncome + CoapplicantIncome
- **Income_Loan_Ratio** = TotalIncome / LoanAmount
- **Log_Income** = ln(TotalIncome)
- **Log_LoanAmount** = ln(LoanAmount)
- **Loan_Per_Term** = LoanAmount / LoanTerm
- **Credit_Income** = Credit_History × TotalIncome

---

## Test Cases & Verification

### Test Case 1: EXCELLENT Applicant (Expected: APPROVED ~95%+)
- **Applicant Income**: Rs 250,000/year
- **Co-applicant Income**: Rs 150,000/year
- **Total Income**: Rs 400,000
- **Loan Amount**: Rs 50,000
- **Income-to-Loan Ratio**: 8.0 (EXCELLENT - >5.0)
- **Loan Term**: 60 months (5 years)
- **Credit History**: Good (1)
- **Gender**: Male
- **Marital Status**: Married
- **Education**: Graduate
- **Self Employed**: No
- **Property Area**: Urban

**Verification Logic**:
- Income-to-Loan Ratio 8.0 > 5.0 ✓ (+40% approx)
- Good credit history ✓ (+30% approx)
- Graduate ✓ (+10%)
- Not self-employed ✓ (+5%)
- Urban property ✓ (+5%)
- Primary income > co-applicant ✓ (+10%)
- **Expected**: High approval (90-98%)
- **Rejection Reasons**: None

---

### Test Case 2: GOOD Applicant (Expected: APPROVED ~70-85%)
- **Applicant Income**: Rs 200,000/year
- **Co-applicant Income**: Rs 100,000/year
- **Total Income**: Rs 300,000
- **Loan Amount**: Rs 80,000
- **Income-to-Loan Ratio**: 3.75 (Good - >2.5)
- **Loan Term**: 84 months (7 years)
- **Credit History**: Good (1)
- **Gender**: Female
- **Marital Status**: Married
- **Education**: Graduate
- **Self Employed**: No
- **Property Area**: Urban

**Verification Logic**:
- Income-to-Loan Ratio 3.75 > 2.5 ✓ (+25%)
- Good credit history ✓ (+30%)
- Graduate ✓ (+10%)
- Not self-employed ✓ (+5%)
- Urban property ✓ (+5%)
- Primary income > co-applicant ✓ (+10%)
- **Expected**: Good approval (70-85%)
- **Rejection Reasons**: None

---

### Test Case 3: MODERATE Applicant (Expected: BORDERLINE ~50-60%)
- **Applicant Income**: Rs 150,000/year
- **Co-applicant Income**: Rs 0/year
- **Total Income**: Rs 150,000
- **Loan Amount**: Rs 60,000
- **Income-to-Loan Ratio**: 2.5 (Borderline - exactly at threshold)
- **Loan Term**: 120 months (10 years)
- **Credit History**: Good (1)
- **Gender**: Male
- **Marital Status**: Single
- **Education**: Not Graduate
- **Self Employed**: No
- **Property Area**: Semiurban

**Verification Logic**:
- Income-to-Loan Ratio 2.5 = threshold (+25%)
- Good credit history ✓ (+30%)
- Not graduate (no bonus)
- Not self-employed ✓ (+5%)
- Semiurban (neutral)
- Single applicant
- **Expected**: Borderline (50-65%)
- **Concern**: No co-applicant, not graduate

---

### Test Case 4: RISKY Applicant (Expected: REJECTED ~20-30%)
- **Applicant Income**: Rs 80,000/year
- **Co-applicant Income**: Rs 40,000/year
- **Total Income**: Rs 120,000
- **Loan Amount**: Rs 150,000
- **Income-to-Loan Ratio**: 0.8 (Poor - <1.5)
- **Loan Term**: 240 months (20 years)
- **Credit History**: Bad (0)
- **Gender**: Male
- **Marital Status**: Married
- **Education**: Not Graduate
- **Self Employed**: Yes
- **Property Area**: Rural

**Verification Logic**:
- Income-to-Loan Ratio 0.8 < 1.5 ✗ (Major negative)
- Bad credit history ✗ (-30% major penalty)
- Not graduate (no bonus)
- Self-employed ✗ (-5% penalty)
- Rural property (neutral)
- Loan is much larger than annual income
- **Expected**: Rejection (10-30%)
- **Rejection Reasons**: Bad credit, poor income-to-loan ratio, self-employed

---

### Test Case 5: CRITICAL Applicant (Expected: REJECTED ~1-5%)
- **Applicant Income**: Rs 60,000/year
- **Co-applicant Income**: Rs 0/year
- **Total Income**: Rs 60,000
- **Loan Amount**: Rs 200,000
- **Income-to-Loan Ratio**: 0.3 (Critical - extremely low)
- **Loan Term**: 360 months (30 years)
- **Credit History**: Bad (0)
- **Gender**: Female
- **Marital Status**: Single
- **Education**: Not Graduate
- **Self Employed**: Yes
- **Property Area**: Rural

**Verification Logic**:
- Income-to-Loan Ratio 0.3 << 1.5 ✗ (Critical - loan 3.3x annual income)
- Bad credit history ✗ (Major penalty)
- Not graduate (no bonus)
- Self-employed ✗ (Penalty)
- Rural property (neutral)
- Single income with very high debt
- **Expected**: Critical rejection (1-5%)
- **Rejection Reasons**: Bad credit, critically low income-to-loan ratio, impossible to repay

---

## Model Accuracy Metrics

From training data:
- Training Accuracy: 99.75%
- Testing Accuracy: 87.5%
- Approval Rate in Training: 53.6%

This indicates:
- Model learns patterns well
- ~12.5% error rate on unseen data (acceptable for lending)
- Balanced approval rate (not too permissive or restrictive)
