"""
Retrain the loan approval model with sensible synthetic data
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import pickle
import os

# Set random seed for reproducibility
np.random.seed(42)

# Generate synthetic training data - 1000 samples
n_samples = 1000

data = {
    'Gender': np.random.choice(['Male', 'Female'], n_samples),
    'Married': np.random.choice(['Yes', 'No'], n_samples),
    'Dependents': np.random.choice([0, 1, 2, 3], n_samples),
    'Education': np.random.choice(['Graduate', 'Not Graduate'], n_samples),
    'Self_Employed': np.random.choice(['Yes', 'No'], n_samples),
    'ApplicantIncome': np.random.uniform(50000, 500000, n_samples),
    'CoapplicantIncome': np.random.uniform(0, 300000, n_samples),
    'LoanAmount': np.random.uniform(10000, 500000, n_samples),
    'Loan_Amount_Term': np.random.choice([36, 60, 84, 120, 180, 240, 360], n_samples),
    'Credit_History': np.random.choice([0, 1], n_samples),
    'Property_Area': np.random.choice(['Urban', 'Semiurban', 'Rural'], n_samples),
}

df = pd.DataFrame(data)

# Create target variable based on sensible business logic
# Loan approved if:
# 1. Good credit history (Credit_History == 1)
# 2. Income-to-loan ratio > 2.0
# 3. Not too heavily dependent on co-applicant income
# 4. Education is graduate
# 5. Not self-employed (slightly lower approval)
# 6. Urban property (slightly better)

df['TotalIncome'] = df['ApplicantIncome'] + df['CoapplicantIncome']
df['Income_Loan_Ratio'] = df['TotalIncome'] / (df['LoanAmount'] + 1)

# Create approval based on sensible logic
approval_score = 0
approval_score += (df['Credit_History'] == 1) * 0.30  # Good credit: +30%
approval_score += (df['Income_Loan_Ratio'] > 2.5) * 0.25  # Good ratio: +25%
approval_score += (df['Income_Loan_Ratio'] > 5.0) * 0.15  # Excellent ratio: +15%
approval_score += (df['ApplicantIncome'] > df['CoapplicantIncome']) * 0.10  # Primary income higher: +10%
approval_score += (df['Education'] == 'Graduate') * 0.10  # Graduate: +10%
approval_score += (df['Property_Area'] == 'Urban') * 0.05  # Urban: +5%
approval_score -= (df['Self_Employed'] == 'Yes') * 0.05  # Self-employed: -5%

# Add some randomness (80% correlation with logic, 20% random)
random_noise = np.random.uniform(0, 0.2, n_samples)
approval_score = approval_score + random_noise

# Apply threshold
df['Loan_Status'] = (approval_score > 0.45).astype(int)

print(f"Generated {n_samples} synthetic samples")
print(f"Approval rate: {df['Loan_Status'].mean()*100:.1f}%")
print(f"\nSample of data:")
print(df.head())

# Feature Engineering
df['Log_Income'] = np.log1p(df['TotalIncome'])
df['Log_LoanAmount'] = np.log1p(df['LoanAmount'])
df['Loan_Per_Term'] = df['LoanAmount'] / (df['Loan_Amount_Term'] + 1)
df['Credit_Income'] = df['Credit_History'] * df['TotalIncome']

# Drop temporary columns
df = df.drop(['ApplicantIncome', 'CoapplicantIncome'], axis=1)

# One-hot encoding for categorical variables
df['Gender_Male'] = (df['Gender'] == 'Male').astype(int)
df['Married_Yes'] = (df['Married'] == 'Yes').astype(int)
df['Education_Not Graduate'] = (df['Education'] == 'Not Graduate').astype(int)
df['Self_Employed_Yes'] = (df['Self_Employed'] == 'Yes').astype(int)
df['Property_Area_Semiurban'] = (df['Property_Area'] == 'Semiurban').astype(int)
df['Property_Area_Urban'] = (df['Property_Area'] == 'Urban').astype(int)

# Drop categorical columns
df = df.drop(['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area'], axis=1)

# Define features (in correct order)
features = [
    'Dependents', 'LoanAmount', 'Loan_Amount_Term', 'Credit_History',
    'TotalIncome', 'Log_Income', 'Log_LoanAmount', 'Income_Loan_Ratio',
    'Loan_Per_Term', 'Credit_Income', 'Gender_Male', 'Married_Yes',
    'Education_Not Graduate', 'Self_Employed_Yes', 'Property_Area_Semiurban',
    'Property_Area_Urban'
]

X = df[features]
y = df['Loan_Status']

print(f"\nFeatures shape: {X.shape}")
print(f"Target distribution:\n{y.value_counts()}")

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Train XGBoost model with optimized parameters
print("\nTraining XGBoost model...")
model = xgb.XGBClassifier(
    n_estimators=100,
    max_depth=5,
    learning_rate=0.1,
    subsample=0.8,
    colsample_bytree=0.8,
    objective='binary:logistic',
    random_state=42,
    eval_metric='logloss'
)

model.fit(X_train, y_train)

# Evaluate
train_score = model.score(X_train, y_train)
test_score = model.score(X_test, y_test)

print(f"Training accuracy: {train_score:.4f}")
print(f"Testing accuracy: {test_score:.4f}")

# Save model and features
os.makedirs('model', exist_ok=True)

with open('model/model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('model/features.pkl', 'wb') as f:
    pickle.dump(features, f)

print("\n✅ Model saved to model/model.pkl")
print("✅ Features saved to model/features.pkl")

# Test with the good applicant profile
print("\n" + "="*60)
print("Testing with good applicant profile:")
print("="*60)

test_data = {
    'Dependents': [0],
    'LoanAmount': [45000],
    'Loan_Amount_Term': [60],
    'Credit_History': [1],
    'TotalIncome': [350000],
    'Log_Income': [np.log1p(350000)],
    'Log_LoanAmount': [np.log1p(45000)],
    'Income_Loan_Ratio': [350000 / 45001],
    'Loan_Per_Term': [45000 / 61],
    'Credit_Income': [350000],
    'Gender_Male': [1],
    'Married_Yes': [1],
    'Education_Not Graduate': [0],
    'Self_Employed_Yes': [0],
    'Property_Area_Semiurban': [0],
    'Property_Area_Urban': [1],
}

test_df = pd.DataFrame(test_data)
pred = model.predict(test_df)[0]
prob = model.predict_proba(test_df)[0]

print(f"Prediction: {pred}")
print(f"Approval Probability: {prob[1]*100:.2f}%")
print(f"Rejection Probability: {prob[0]*100:.2f}%")
print(f"Decision: {'✅ APPROVED' if pred == 1 else '❌ REJECTED'}")
