from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pickle
import numpy as np
import pandas as pd
import os
import sqlite3
from datetime import datetime
import uuid
import json

app = FastAPI()

# Allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "loan_data.db")

def init_db():
    """Initialize SQLite database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Predictions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            education TEXT,
            applicant_income REAL,
            coapplicant_income REAL,
            loan_amount REAL,
            loan_term INTEGER,
            credit_history INTEGER,
            property_area TEXT,
            predicted_status TEXT,
            probability REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# Load model + features
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model_path = os.path.join(base_dir, "model", "model.pkl")
features_path = os.path.join(base_dir, "model", "features.pkl")
model = pickle.load(open(model_path, "rb"))
features = pickle.load(open(features_path, "rb"))

def get_user_id(email):
    """Get user ID from email"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

@app.get("/")
def home():
    return {"message": "Loan Prediction API Running", "status": "ok"}

@app.post("/signup")
def signup(email: str, password: str, name: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        cursor.execute("INSERT INTO users (email, password, name) VALUES (?, ?, ?)", 
                      (email, password, name))
        conn.commit()
        return {"message": "Signup successful", "email": email}
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="User already exists")
    finally:
        conn.close()

@app.post("/login")
def login(email: str, password: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, password FROM users WHERE email = ?", (email,))
    result = cursor.fetchone()
    conn.close()
    
    if not result or result[2] != password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    return {
        "message": "Login successful",
        "email": email,
        "name": result[1],
        "token": str(uuid.uuid4())
    }

@app.post("/predict")
def predict(email: str, data: dict):
    user_id = get_user_id(email)
    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # DEBUG: Print received data
    print(f"DEBUG - Received data: {data}")
    
    df = pd.DataFrame([data])

    # Feature engineering
    df['TotalIncome'] = df['ApplicantIncome'] + df['CoapplicantIncome']
    df['Log_Income'] = np.log1p(df['TotalIncome'])
    df['Log_LoanAmount'] = np.log1p(df['LoanAmount'])
    df['Income_Loan_Ratio'] = df['TotalIncome'] / (df['LoanAmount'] + 1)
    df['Loan_Per_Term'] = df['LoanAmount'] / (df['Loan_Amount_Term'] + 1)
    df['Credit_Income'] = df['Credit_History'] * df['TotalIncome']

    df = df.drop(['ApplicantIncome', 'CoapplicantIncome'], axis=1)
    
    # Manual one-hot encoding for categorical variables
    # This ensures we get the exact column names the model expects
    df['Gender_Male'] = (df['Gender'] == 'Male').astype(int)
    df['Married_Yes'] = (df['Married'] == 'Yes').astype(int)
    df['Education_Not Graduate'] = (df['Education'] == 'Not Graduate').astype(int)
    df['Self_Employed_Yes'] = (df['Self_Employed'] == 'Yes').astype(int)
    df['Property_Area_Semiurban'] = (df['Property_Area'] == 'Semiurban').astype(int)
    df['Property_Area_Urban'] = (df['Property_Area'] == 'Urban').astype(int)
    
    # Drop original categorical columns
    df = df.drop(['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area'], axis=1)
    
    # Ensure all expected features exist
    for col in features:
        if col not in df.columns:
            df[col] = 0
    
    # Select only the features the model was trained on, in correct order
    df = df[features]

    pred = model.predict(df)[0]
    prob = model.predict_proba(df)[0][1]
    
    # Generate explanation
    approval_prob = round(float(prob) * 100, 2)
    rejection_prob = round(100 - float(prob) * 100, 2)
    
    # Basis for decision
    income_loan_ratio = float(data['ApplicantIncome'] + data['CoapplicantIncome']) / float(data['LoanAmount']) if data['LoanAmount'] > 0 else 0
    credit_score = int(data.get('Credit_History', 0))
    education = data.get('Education', 'Unknown')
    
    basis = []
    if credit_score == 0:
        basis.append("Poor credit history")
    if income_loan_ratio < 1.5:
        basis.append("Low income-to-loan ratio")
    if data['LoanAmount'] > 500000:
        basis.append("High loan amount requested")
    
    explanation = f"Approval probability: {approval_prob}%. Rejection probability: {rejection_prob}%."
    if basis:
        explanation += f" Factors affecting decision: {', '.join(basis)}."
    else:
        explanation += " Strong profile based on income, credit history, and loan ratio."
    
    result = {
        "Loan_Status": "Approved" if pred == 1 else "Rejected",
        "Probability": approval_prob,
        "Rejection_Probability": rejection_prob,
        "Explanation": explanation,
        "Basis": {
            "credit_history": credit_score,
            "income_loan_ratio": round(income_loan_ratio, 2),
            "loan_amount": data['LoanAmount'],
            "education": education
        }
    }
    
    # Save to database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO predictions 
        (user_id, education, applicant_income, coapplicant_income, loan_amount, 
         loan_term, credit_history, property_area, predicted_status, probability)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        user_id,
        data.get('Education'),
        data.get('ApplicantIncome'),
        data.get('CoapplicantIncome'),
        data.get('LoanAmount'),
        data.get('Loan_Amount_Term'),
        data.get('Credit_History'),
        data.get('Property_Area'),
        result['Loan_Status'],
        result['Probability']
    ))
    conn.commit()
    conn.close()
    
    return result

@app.get("/analytics/{email}")
def get_analytics(email: str):
    user_id = get_user_id(email)
    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Get all predictions
    cursor.execute("""
        SELECT id, education, applicant_income, coapplicant_income, loan_amount,
               credit_history, predicted_status, probability, created_at
        FROM predictions WHERE user_id = ? ORDER BY created_at DESC
    """, (user_id,))
    
    predictions = cursor.fetchall()
    conn.close()
    
    if not predictions:
        return {
            "total_predictions": 0,
            "approved_count": 0,
            "rejected_count": 0,
            "approval_rate": 0,
            "avg_loan_amount": 0,
            "avg_probability": 0,
            "predictions": []
        }
    
    approved = sum(1 for p in predictions if p[6] == 'Approved')
    rejected = len(predictions) - approved
    avg_loan = sum(p[4] or 0 for p in predictions) / len(predictions)
    avg_prob = sum(p[7] or 0 for p in predictions) / len(predictions)
    
    pred_list = []
    for p in predictions[:10]:
        pred_list.append({
            "id": p[0],
            "education": p[1],
            "applicant_income": p[2],
            "coapplicant_income": p[3],
            "loan_amount": p[4],
            "credit_history": p[5],
            "status": p[6],
            "probability": p[7],
            "timestamp": p[8]
        })
    
    return {
        "total_predictions": len(predictions),
        "approved_count": approved,
        "rejected_count": rejected,
        "approval_rate": round((approved / len(predictions)) * 100, 2) if len(predictions) > 0 else 0,
        "avg_loan_amount": round(avg_loan, 2),
        "avg_probability": round(avg_prob, 2),
        "predictions": pred_list
    }

@app.get("/profile/{email}")
def get_profile(email: str):
    user_id = get_user_id(email)
    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT name, created_at FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    
    cursor.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ?", (user_id,))
    total_preds = cursor.fetchone()[0]
    
    conn.close()
    
    return {
        "email": email,
        "name": user[0],
        "total_predictions": total_preds,
        "member_since": user[1].split()[0] if user[1] else "2024-01-01"
    }

@app.get("/historical-data/{email}")
def get_historical_data(email: str):
    """Get historical data for analysis and suggestions"""
    user_id = get_user_id(email)
    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT loan_amount, credit_history, predicted_status, probability
        FROM predictions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50
    """, (user_id,))
    
    data = cursor.fetchall()
    conn.close()
    
    if not data:
        return {"message": "No historical data", "data": []}
    
    # Calculate insights
    avg_approved_prob = np.mean([p[3] for p in data if p[2] == 'Approved']) if any(p[2] == 'Approved' for p in data) else 0
    avg_rejected_prob = np.mean([p[3] for p in data if p[2] == 'Rejected']) if any(p[2] == 'Rejected' for p in data) else 0
    
    return {
        "data": [{"loan": p[0], "credit": p[1], "status": p[2], "prob": p[3]} for p in data],
        "insights": {
            "avg_approved_probability": round(float(avg_approved_prob), 2),
            "avg_rejected_probability": round(float(avg_rejected_prob), 2),
            "recommendation": "Higher credit history and lower loan ratio improves approval chances" if avg_approved_prob > avg_rejected_prob else "Consider improving credit history"
        }
    }
